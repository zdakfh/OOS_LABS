
#include <stdio.h>

int main() {
    printf("Hello, world, from C!\n");
    return 0;
}
